# CV — Huỳnh Vũ Linh (LaTeX / Texpage) — Timeline + Icon + Thẻ dự án

## Cách dùng trên Texpage
1. Vào Texpage → **Tạo dự án mới** → **Import/Upload** → chọn file `.zip` này.
2. Trình biên dịch: **XeLaTeX** (bắt buộc — vừa để hiển thị đúng dấu tiếng Việt,
   vừa để nạp được font icon đi kèm). File `main.tex` có dòng
   `% !TeX program = xelatex` ở đầu để tự nhận diện; nếu Texpage không tự nhận,
   vào **Cài đặt dự án → Compiler → XeLaTeX**.
3. File chính để biên dịch: `main.tex`. Biên dịch **2 lần liên tiếp** nếu thấy
   khối 2 cột (Kỹ năng/Học vấn, Người tham chiếu) chưa canh đều — đây là hành vi
   bình thường của LaTeX khi có nội dung phụ thuộc kích thước trang.

## File đi kèm
- `main.tex` — code CV.
- `photo_circle.png` — ảnh đại diện đã tách nền tròn.
- `FontAwesome.ttf` — **font icon Font Awesome 4.7**, giấy phép SIL OFL (miễn phí,
  dùng thoải mái kể cả thương mại). Bắt buộc phải nằm cùng thư mục với `main.tex`
  vì file này được nạp trực tiếp bằng đường dẫn tương đối (không cần cài đặt gì
  thêm trên Texpage).

## Những thay đổi theo yêu cầu mới nhất
- **Kỹ năng + Học vấn**: gộp thành khối 2 cột, đặt tại đúng vị trí mục Kỹ năng cũ.
- **Icon đơn sắc xanh/xám**: thêm icon Font Awesome cho toàn bộ tiêu đề mục,
  thông tin liên hệ, và từng thẻ dự án — dùng chung 1 tông màu xanh xám đậm
  (`accent`, mã màu #45536B) cho đồng bộ.
- **Dự án tiêu biểu**: chuyển từ danh sách chữ sang **lưới thẻ (card) 2 cột**,
  mỗi thẻ có icon minh họa riêng theo chủ đề dự án, huy hiệu (badge) nêu bật
  quy mô/diện tích, và mô tả viết lại theo hướng sinh động hơn.
- **Người tham chiếu**: đã xóa tên thật, để trống 3 dòng (Họ và tên / Chức danh /
  Liên hệ) cho 2 người tham chiếu — anh tự điền trực tiếp trong Texpage.
- **Nền trang**: đổi từ trắng thuần sang xám xanh rất nhạt (#F5F6F8) — vẫn trang
  trọng, các thẻ/nội dung nền trắng nổi bật rõ trên nền này.

## Muốn chỉnh thêm?
- Đổi màu icon/accent: sửa `\definecolor{accent}{HTML}{...}`.
- Đổi màu nền trang: sửa `\definecolor{pagebg}{HTML}{...}`.
- Đổi icon một mục nào đó: mỗi icon được gọi bằng mã hex 4 ký tự của Font Awesome
  4 (vd `\cvsection{F0B1}{Kinh nghiệm làm việc}` — F0B1 là icon vali). Tra mã tại
  trang "Font Awesome 4.7 cheatsheet" nếu muốn đổi.
- Thêm/bớt thẻ dự án: dùng lệnh `\cardrow{...}{...}` cho mỗi hàng 2 thẻ; mỗi thẻ
  gọi bằng `\projectcard{mã icon}{tiêu đề}{badge}{mô tả}`.
